
import React, { useState } from 'react';
import { useData } from '../context/DataContext';

interface FooterProps {
  onNavigate: (page: 'home' | 'menu' | 'drinks' | 'gallery' | 'imageEditor' | 'admin' | 'terms' | 'events' | 'blog' | 'songs') => void;
}

const FooterSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="border-b border-zinc-800 md:border-none">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center py-5 md:py-0 md:mb-6 md:cursor-default group"
      >
        <h5 className="font-black text-white uppercase tracking-[0.2em] text-[11px] md:text-xs group-hover:text-pink-500 transition-colors">{title}</h5>
        <span className={`md:hidden transition-transform duration-300 text-zinc-500 ${isOpen ? 'rotate-180' : ''}`}>
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M19 9l-7 7-7-7"/></svg>
        </span>
      </button>
      <div className={`${isOpen ? 'max-h-[500px] opacity-100' : 'max-h-0 md:max-h-none opacity-0 md:opacity-100'} overflow-hidden transition-all duration-500 ease-in-out md:block`}>
        <ul className="space-y-3 pb-6 md:pb-0 text-zinc-400">
          {children}
        </ul>
      </div>
    </div>
  );
};

const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const { footerData } = useData();
  const BOOKING_URL = "https://squareup.com/appointments/book/aijx16oiq683tl/LCK48B0G6CF51/services";

  const handleScrollToOffers = () => {
    onNavigate('home');
    setTimeout(() => {
        const section = document.getElementById('special-offers');
        if (section) {
            section.scrollIntoView({ behavior: 'smooth' });
        }
    }, 100);
  };

  return (
    <footer className="bg-black text-zinc-500 text-[11px] border-t border-zinc-900">
      <div className="container mx-auto px-6 pt-16 pb-12">
        {/* Call to Action */}
        <div className="text-center mb-20">
          <h4 className="text-4xl md:text-5xl font-black text-white mb-6 tracking-tighter italic uppercase">{footerData.ctaHeading}</h4>
          <p className="text-zinc-400 mb-10 max-w-lg mx-auto text-base md:text-lg leading-relaxed font-light">{footerData.ctaText}</p>
          <a 
            href={BOOKING_URL} 
            target="_blank" 
            rel="noopener noreferrer" 
            className="inline-block bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-300 hover:to-orange-400 text-black text-xs font-black py-4 px-10 rounded-full transition-all duration-300 ease-in-out hover:scale-110 uppercase tracking-widest shadow-[0_10px_30px_rgba(251,191,36,0.3)]"
          >
            {footerData.ctaButtonText}
          </a>
        </div>

        {/* Reorganized Navigation Links */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-x-12 mb-20 border-t border-zinc-900 md:border-none">
          <FooterSection title="Explore Soho">
            <li><button onClick={() => onNavigate('home')} className="hover:text-pink-500 transition-colors">Home</button></li>
            <li><button onClick={() => onNavigate('gallery')} className="hover:text-pink-500 transition-colors">Visual Archive</button></li>
            <li><button onClick={() => onNavigate('songs')} className="hover:text-pink-500 transition-colors">Song Library</button></li>
            <li><button onClick={() => onNavigate('blog')} className="hover:text-pink-500 transition-colors">LKC Blog</button></li>
          </FooterSection>

          <FooterSection title="Eat & Drink">
            <li><button onClick={() => onNavigate('menu')} className="hover:text-pink-500 transition-colors">Food Platter Menu</button></li>
            <li><button onClick={() => onNavigate('drinks')} className="hover:text-pink-500 transition-colors">Signature Cocktails</button></li>
            <li><button onClick={handleScrollToOffers} className="hover:text-pink-500 transition-colors">Special Offers</button></li>
          </FooterSection>

          <FooterSection title="Private Parties">
            <li><button onClick={() => onNavigate('events')} className="hover:text-pink-500 transition-colors">Hen & Stag Parties</button></li>
            <li><button onClick={() => onNavigate('events')} className="hover:text-pink-500 transition-colors">Corporate Hire</button></li>
            <li><button onClick={() => onNavigate('events')} className="hover:text-pink-500 transition-colors">Birthdays</button></li>
          </FooterSection>

          <FooterSection title="Connect">
            <li><a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="hover:text-pink-500 transition-colors">Instagram</a></li>
            <li><a href="https://tiktok.com" target="_blank" rel="noopener noreferrer" className="hover:text-pink-500 transition-colors">TikTok</a></li>
            <li><a href="https://wa.me/447761383514" target="_blank" rel="noopener noreferrer" className="hover:text-green-500 transition-colors">WhatsApp Support</a></li>
          </FooterSection>
        </div>

        {/* Footer Bottom */}
        <div className="pt-12 border-t border-zinc-900 flex flex-col md:flex-row justify-between items-center gap-8">
            <div className="flex flex-col md:flex-row gap-4 items-center text-center md:text-left">
                <div className="w-12 h-12 relative flex-shrink-0 mb-4 md:mb-0">
                    <img src="https://assets.zyrosite.com/cdn-cgi/image/format=auto,w=375,fit=crop,q=95/m7V3XokxQ0Hbg2KE/new-YNq2gqz36OInJMrE.png" alt="LKC" className="w-full h-full object-contain grayscale opacity-50" />
                </div>
                <div>
                    <p className="text-zinc-500 font-bold uppercase tracking-widest mb-1">London Karaoke Club Soho</p>
                    <p className="text-zinc-600">Copyright © 2024. All rights reserved.</p>
                </div>
            </div>
            
            <div className="flex flex-wrap justify-center gap-x-6 gap-y-3 uppercase font-black tracking-widest text-[9px] text-zinc-600">
                <button onClick={() => onNavigate('terms')} className="hover:text-white transition-colors">Privacy</button>
                <button onClick={() => onNavigate('terms')} className="hover:text-white transition-colors">Terms</button>
                <button onClick={() => onNavigate('terms')} className="hover:text-white transition-colors">Booking Policy</button>
                <button onClick={() => onNavigate('admin')} className="hover:text-pink-500 transition-colors">CMS Access</button>
            </div>
        </div>
        
        <div className="mt-8 text-center md:text-left">
             <p className="text-zinc-700 font-medium">Located in the heart of London. Call +44 7761 383514.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
