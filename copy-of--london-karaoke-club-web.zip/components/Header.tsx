
import React, { useState, useEffect } from 'react';
import { useData } from '../context/DataContext';

interface HeaderProps {
  onNavigate: (page: 'home' | 'menu' | 'drinks' | 'gallery' | 'imageEditor' | 'admin' | 'terms' | 'songs' | 'events' | 'blog') => void;
}

const Header: React.FC<HeaderProps> = ({ onNavigate }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const { headerData } = useData();
  
  const BOOKING_URL = "https://squareup.com/appointments/book/aijx16oiq683tl/LCK48B0G6CF51/services";

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Lock scroll when mobile menu is open
  useEffect(() => {
    if (isMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
  }, [isMenuOpen]);

  const navLinks = headerData.navOrder || ["menu", "gallery", "blog", "drinks", "events", "songs"];

  const getLabel = (key: string) => {
    if (!key) return "";
    switch(key) {
      case 'home': return 'HOME';
      case 'menu': return 'FOOD';
      case 'gallery': return 'GALLERY';
      case 'blog': return 'BLOG';
      case 'drinks': return 'DRINKS';
      case 'events': return 'EVENTS';
      case 'songs': return 'SONGS';
      default: return key.toUpperCase();
    }
  };

  const handleLinkClick = (page: string) => {
    onNavigate(page as any);
    setIsMenuOpen(false);
  };

  return (
    <header 
      className={`fixed top-0 left-0 w-full z-[100] transition-all duration-500 ${
        isScrolled ? 'bg-black/80 backdrop-blur-xl py-3 border-b border-zinc-800/50 shadow-2xl' : 'bg-transparent py-6'
      }`}
    >
      <div className="container mx-auto px-6">
        <div className="flex items-center justify-between">
          
          {/* Left Wing: Book Now (Desktop) or Just Button */}
          <div className="flex-1 flex justify-start">
            <a 
              href={BOOKING_URL} 
              target="_blank" 
              rel="noopener noreferrer" 
              className="group relative overflow-hidden bg-white hover:bg-pink-600 text-black hover:text-white px-5 py-2.5 md:px-8 md:py-3 rounded-full transition-all duration-300 shadow-[0_10px_30px_rgba(255,255,255,0.1)] hover:shadow-pink-600/30"
            >
              <span className="relative z-10 text-[10px] md:text-xs font-black uppercase tracking-[0.2em] transition-colors duration-300">Book Now</span>
            </a>
          </div>

          {/* Center: Brand Logo */}
          <div className="flex-shrink-0 z-10">
            <button onClick={() => handleLinkClick('home')} className="flex items-center transition-transform hover:scale-105 active:scale-95 duration-300">
              <img 
                src={headerData.logoUrl} 
                alt="London Karaoke Club" 
                className={`transition-all duration-500 object-contain ${isScrolled ? 'h-10 md:h-12' : 'h-14 md:h-20'}`} 
              />
            </button>
          </div>

          {/* Right Wing: Desktop Nav + Hamburger */}
          <div className="flex-1 flex justify-end items-center">
            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center gap-8 mr-8">
              {navLinks.map((link) => (
                <button 
                  key={link} 
                  onClick={() => handleLinkClick(link)}
                  className="relative text-[10px] font-black uppercase tracking-[0.25em] text-zinc-400 hover:text-white transition-colors group"
                >
                  {getLabel(link)}
                  <span className="absolute -bottom-1 left-0 w-0 h-[2px] bg-pink-500 transition-all duration-300 group-hover:w-full"></span>
                </button>
              ))}
            </nav>

            {/* Hamburger Button */}
            <button 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="relative z-[120] w-10 h-10 flex flex-col items-center justify-center bg-zinc-900/50 hover:bg-zinc-800 border border-zinc-800 rounded-full transition-all group"
              aria-label="Toggle Menu"
            >
              <div className="w-5 h-4 flex flex-col justify-between overflow-hidden">
                <span className={`w-full h-0.5 bg-white transition-all duration-300 ${isMenuOpen ? 'rotate-45 translate-y-[7px]' : ''}`}></span>
                <span className={`w-full h-0.5 bg-white transition-all duration-300 ${isMenuOpen ? 'opacity-0 translate-x-4' : ''}`}></span>
                <span className={`w-full h-0.5 bg-white transition-all duration-300 ${isMenuOpen ? '-rotate-45 -translate-y-[7px]' : ''}`}></span>
              </div>
            </button>
          </div>
        </div>
      </div>

      {/* Modern Fullscreen Mobile Menu */}
      <div 
        className={`fixed inset-0 bg-black/95 backdrop-blur-2xl z-[110] transition-all duration-700 ease-in-out ${
          isMenuOpen ? 'translate-y-0 opacity-100 pointer-events-auto' : '-translate-y-full opacity-0 pointer-events-none'
        }`}
      >
        {/* Animated Background Gradients */}
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-pink-600/10 rounded-full blur-[120px] pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-purple-600/10 rounded-full blur-[120px] pointer-events-none"></div>

        <div className="flex flex-col h-full container mx-auto px-8 pt-32 pb-12 overflow-y-auto">
          <nav className="flex flex-col gap-6 md:gap-8 mb-16">
            <button 
              onClick={() => handleLinkClick('home')}
              className={`text-5xl md:text-8xl font-black uppercase tracking-tighter text-left hover:text-pink-500 transition-all italic transform ${isMenuOpen ? 'translate-x-0 opacity-100' : '-translate-x-12 opacity-0'}`}
              style={{ transitionDelay: '100ms' }}
            >
              HOME
            </button>
            {navLinks.map((link, idx) => (
              <button 
                key={link} 
                onClick={() => handleLinkClick(link)}
                className={`text-5xl md:text-8xl font-black uppercase tracking-tighter text-left hover:text-pink-500 transition-all italic transform ${isMenuOpen ? 'translate-x-0 opacity-100' : '-translate-x-12 opacity-0'}`}
                style={{ transitionDelay: `${200 + idx * 50}ms` }}
              >
                {getLabel(link)}
              </button>
            ))}
            <a 
              href={BOOKING_URL}
              target="_blank"
              rel="noopener noreferrer"
              className={`text-5xl md:text-8xl font-black uppercase tracking-tighter text-left text-yellow-400 italic hover:text-white transition-all transform ${isMenuOpen ? 'translate-x-0 opacity-100' : '-translate-x-12 opacity-0'}`}
              style={{ transitionDelay: `${200 + navLinks.length * 50}ms` }}
            >
              BOOK NOW
            </a>
          </nav>

          {/* Mobile Menu Footer Info */}
          <div className={`mt-auto grid grid-cols-1 md:grid-cols-2 gap-8 pt-12 border-t border-zinc-800 transition-all duration-700 ${isMenuOpen ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`} style={{ transitionDelay: '600ms' }}>
            <div>
              <p className="text-zinc-500 text-[10px] font-black uppercase tracking-[0.3em] mb-4">Location</p>
              <p className="text-white font-bold text-lg md:text-xl">London Karaoke Club Soho</p>
              <p className="text-zinc-400">Step inside the most exclusive stage in London.</p>
            </div>
            <div className="md:text-right">
              <p className="text-zinc-500 text-[10px] font-black uppercase tracking-[0.3em] mb-4">Contact</p>
              <p className="text-white font-bold text-lg md:text-xl hover:text-pink-500 transition-colors cursor-pointer">+44 7761 383514</p>
              <p className="text-zinc-400">info@londonkaraoke.club</p>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
